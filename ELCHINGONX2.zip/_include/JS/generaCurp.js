/**
 * Created by magumbo on 3/21/17.
 */
function makeCurp() {
    var curp = generaCurp({
        nombre            : document.getElementById("nom").value,
        apellido_paterno  : document.getElementById("pat").value,
        apellido_materno  : document.getElementById("mat").value,
        sexo              : document.getElementById("sexo").value,
        estado            : document.getElementById("estado").value,
        fecha_nacimiento  : [document.getElementById("dia").value, document.getElementById("mes").value, document.getElementById("anio").value]
    });
    alert(curp);
}