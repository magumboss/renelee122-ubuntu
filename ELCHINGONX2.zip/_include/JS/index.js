$("document").ready(function()
{
    $(".form-login").submit(function()
    {
        var datos =
            {
                'accion' : 'login',
                'curp' : document.getElementById("curp").value
            };
        $.ajax
        ({
            type: "POST",
            dataType: "json",
            url: "_include/PHP/index.php",
            data: datos,
            success: function(datos)
            {
                if(datos['respuesta'])
                {
                    $(".lolazo").load('_include/PHP/fichas.php');
                }
                else
                {
                    alert('CURP incorrecta o no está registrada');
                }
            }
        });
        return false;
    });


    $.ajax({
        url : '_include/PHP/sesion.php',
        type : 'POST',
        dataType : 'json',
        success : function (result)
        {
            $(".lolazo").load('_include/PHP/fichas.php');
        },
        error : function (xhr, status, err)
        {
        }
    });
});

