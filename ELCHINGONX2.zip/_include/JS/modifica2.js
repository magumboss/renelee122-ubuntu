/**
 * Created by magumbo on 3/26/17.
 */
document.getElementById("modificafull").onclick = function () {
    BootstrapDialog.show({
        title: 'Modifica tus Datos',
        message: $('<div></div>').load('_include/PHP/modificaDatosObligatorio.php')
    });
};
document.getElementById("modificafullLink").onclick = function () {
    BootstrapDialog.show({
        title: 'Modifica tus Datos',
        message: $('<div></div>').load('_include/PHP/modificaDatosObligatorio.php')
    });
};