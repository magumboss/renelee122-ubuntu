<?php
class referencia_pago 
{
	private $ficha;
	private $concepto;
	private $concecutivo;
	private $fecha;
	private $importe;
	private $ref;
	public function __construct($sol,$cpto,$ctvo,$fech,$imp)
	{
		$this -> ficha = trim($sol);
		$this -> concepto = trim($cpto);
		$this -> concecutivo = trim($ctvo);
		$this -> fecha = trim($fech);	
		$this -> importe = trim($imp);
	}
	private function fecha_condensada()
	{
		$ano = ( intval( substr ( $this -> fecha, 6, 4 ) ) - 2013 ) * 372;
		$mes = ( intval( substr ( $this -> fecha, 3, 2 ) ) - 1 ) * 31;
		$dia = intval( substr ( $this -> fecha, 0, 2 ) ) - 1;
		return $ano + $mes + $dia;
	}
	private function importe_condensado()
	{
		$imp = array();
		$fac = array( 3, 7, 1, 3, 7, 1, 3, 7 );	
		$sum = 0;			
		for ( $i=0 ; $i<8 ; $i++ )
		{	
			$val = intval( substr ($this -> importe, $i, 1 ) );	
			$val *= $fac[$i];
			$sum += $val;
		}
		$sum %= 10;
		return $sum;
	}
	private function digito_verificador($ref)
	{
		$alfa=array
		( 
			'A'=>'2', 'B'=>'2', 'C'=>'2', 
			'D'=>'3', 'E'=>'3', 'F'=>'3', 
			'G'=>'4', 'H'=>'4', 'I'=>'4', 
			'J'=>'5', 'K'=>'5', 'L'=>'5', 
			'M'=>'6', 'N'=>'6', 'O'=>'6', 
			'P'=>'7', 'Q'=>'7', 'R'=>'7', 
			'S'=>'8', 'T'=>'8', 'U'=>'8', 
			'V'=>'9', 'W'=>'9', 'X'=>'9', 
			'Y'=>'0', 'Z'=>'0' 
		);
		foreach( $alfa as $l => $v )
		{	
			$ref= str_replace( $l, $v, $ref );
		}					
		$fac=array
		( 
			17, 13, 11, 23, 19, 
			17, 13, 11, 23, 19, 
			17, 13, 11, 23, 19, 
			17, 13, 11, 23, 19, 
			17, 13, 11, 23, 19, 
			17, 13, 11, 23, 19, 
			17, 13, 11, 23, 19, 
			17, 13, 11, 23, 19 
		);	
		$sum=0;			
		for ( $i = 0 ; $i < strlen( $ref ); $i ++ )
		{	
			$val = intval( substr( $ref, $i, 1 ) );	
			$val *= $fac[ $i ];
			$sum+=$val;
		}	
		$sum %= 97;	
		$sum += 1;	
		if ( strlen( $sum ) == 1 )
		{
			$sum = '0' . $sum;
		}
		return $sum;
	
	}
	public function main()
	{
		$this -> ref = $this -> ficha . $this -> concepto . $this -> concecutivo . $this -> fecha_condensada() . $this -> importe_condensado() . '2';
		$this -> ref .= $this -> digito_verificador( $this -> ref );
		return $this -> ref;
	}
}




