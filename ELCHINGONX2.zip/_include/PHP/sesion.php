<?php
session_start();
if(isset($_SESSION['CURP']) && !empty($_SESSION['CURP'])) {
    $return_data = ['CURP' => $_SESSION['CURP']];
    echo json_encode($return_data);
}
