<?php
/**
 * Created by PhpStorm.
 * User: magumbo
 * Date: 3/22/17
 * Time: 10:39 PM
 */

include ("config.php");

if (isset($_GET['estcve']) && isset($_GET['muncve'])) {

    $estcve = $_GET['estcve'];
    $muncve = $_GET['muncve'];
    $query = "SELECT esccve,escnom FROM escuelas WHERE estcve = $estcve AND muncve = $muncve";

    $rows = sql($db, $query, "rows");

    foreach($rows as $row) {
        $result[] = array(
            'esccve' => $row['esccve'],
            'escnom' => $row['escnom']
        );
    }


    echo json_encode($result);
}