<?php
/**
 * Created by PhpStorm.
 * User: magumbo
 * Date: 3/23/17
 * Time: 9:10 AM
 */


define("HOST", "localhost");
define("USER", "majumbo");
define("PASS", "12345");
define("DB", "fichas");


try {
    $db = new PDO("mysql:host=".HOST.";dbname=".DB.";charset=utf8", "".USER."", "".PASS."");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo $e->getMessage();
}

function sql($db, $q, $return) {
    $stmt = $db->prepare($q);
    $stmt->execute();
    if ($return == "rows") {
        return $stmt->fetchAll();
    }
    elseif ($return == "count") {
        return $stmt->rowCount();
    }




}

function sql4($db, $q, $params, $return) {
    // Prepare statement
    $stmt = $db->prepare($q);
    // Execute statement
    $stmt->execute($params);
    // Decide whether to return the rows themselves, or just count the rows
    if ($return == "rows") {
        return $stmt->fetchAll();
    }
    elseif ($return == "count") {
        return $stmt->rowCount();
    }
}

function sql6($db, $q) {
    $stmt = $db->prepare($q);
    $stmt->execute();
    return $stmt->fetchAll();

}

function sql2($db, $q) {
    $stmt = $db->prepare($q);
    $stmt->execute();

}

function carreras($db, $id) {
    $q = "SELECT nombre FROM carreras WHERE cve = $id";
    $stmt = $db->prepare($q);
    $stmt->execute();
    return $stmt->fetchAll();
}

function estados($db, $id) {
    $q = "SELECT estnom FROM estados WHERE estcve = $id";
    $stmt = $db->prepare($q);
    $stmt->execute();
    return $stmt->fetchAll();
}

function fechas($db, $id) {
    $q = "SELECT * FROM pagos WHERE referencia =' ".$id."'";
    $stmt = $db->prepare($q);
    $stmt->execute();
    return $stmt->fetchAll();
}


function escuelas($db, $estcve, $muncve, $esccve) {
    $q = "SELECT escnom FROM escuelas WHERE estcve = $estcve AND muncve = $muncve AND esccve = $esccve";
    $stmt = $db->prepare($q);
    $stmt->execute();
    return $stmt->fetchAll();
}

function asignar($db, $id) {
    $q = "INSERT INTO numfichas (asignadas, id_aspirante) VALUES (null, $id)";
    $stmt = $db->prepare($q);
    $stmt->execute();
    $q2 = "SELECT asignadas FROM numfichas WHERE id_aspirante = $id";
    $stmt2 = $db->prepare($q2);
    $stmt2->execute();
    return $stmt2->fetchAll();
}