<?php
session_start();
if (!isset($_SESSION['CURP']))
{
    echo "<meta http-equiv='refresh' content='0;url=/'>";
}
/**
 * Created by PhpStorm.
 * User: magumbo
 * Date: 3/21/17
 * Time: 3:55 PM
 */
if (isset($_GET["pag"])) {
    $_SESSION['pag'] = $_GET["pag"];
    echo "<meta http-equiv='refresh' content='0;url=/'>";
}
$active = $_SESSION['pag'];

echo '


            
                <ul class="nav navbar-nav side-nav">';
    switch ($active) {
        case "1":
            echo '
    <li class = "active">
    <a href = "_include/PHP/fichas.php?pag=1"><i class = "fa fa-fw fa-info"></i> Datos Generales</a>
    </li>
   
    <li>
    <a class="disabled" href = "_include/PHP/fichas.php?pag=3"><i class = "fa fa-fw fa-pencil-square-o"></i> CENEVAL</a>
    </li>';
            break;

        case "3":
            echo '
    <li>
    <a href = "_include/PHP/fichas.php?pag=1"><i class = "fa fa-fw fa-info"></i> Datos Generales</a>
    </li>
  
    <li class = "active">
    <a class="disabled" href = "_include/PHP/fichas.php?pag=3"><i class = "fa fa-fw fa-pencil-square-o"></i> CENEVAL</a>
    </li>';
            break;
        default:
            echo '
    <li class = "active">
    <a href = "_include/PHP/fichas.php?pag=1"><i class = "fa fa-fw fa-info"></i> Datos Generales</a>
    </li>
    
    <li>
    <a class="disabled" href = "_include/PHP/fichas.php?pag=3"><i class = "fa fa-fw fa-pencil-square-o"></i> CENEVAL</a>
    </li>';
    }


echo '
                </ul>
       </div>

            <!-- /.navbar-collapse -->
        </nav>
        
';


