<?php
/*ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);*/
/**
 * Created by PhpStorm.
 * User: magumbo
 * Date: 3/25/17
 * Time: 11:02 PM
 */
include ("config.php");
include ("ref.php");
session_start();

if ($_POST['municipionac'] == ""){
    $municipionac = "null";
}else{
    $municipionac   = $_POST['municipionac'];
}

if ($_POST['municipioproc'] == ""){
    $municipioproc = "null";
}else{
    $municipioproc   = $_POST['municipioproc'];
}

if ($_POST['municipioact'] == ""){
    $municipioact = "null";
}else{
    $municipioact   = $_POST['municipioact'];
}

if ($_POST['rfc'] == ""){
    $rfc = "null";
}else{
    $rfc   = $_POST['rfc'];
}
if ($_POST['escuela'] == ""){
    $escuela = "null";
}else{
    $escuela   = $_POST['escuela'];
}

$id             = $_SESSION['info']['id'];
$mocurp         = $_POST['mocurp'];
$nom            = $_POST['nom'];
$pat            = $_POST['pat'];
$mat            = $_POST['mat'];
$fechanac       = $_POST['dianac']."/".$_POST['mesnac']."/".$_POST['anionac'];
$estadonac      = $_POST['estadonac'];
$telfijo        = $_POST['telfijo'];
$cel            = $_POST['cel'];
$correo         = $_POST['correo'];
$calle          = $_POST['calle'];
$numcalle       = $_POST['numcalle'];
$col            = $_POST['col'];
$cp             = $_POST['cp'];
$estadoact      = $_POST['estadoact'];
$estadoproc     = $_POST['estadoproc'];
$egresoesc      = $_POST['egresoesc'];
$prom           = $_POST['prom'];


if(isset($_POST['full'])){
    $query = "UPDATE aspirantes SET 
            curp = '".$mocurp."',
            nombre = '".$nom."',
            paterno = '".$pat."',
            materno = '".$mat."',
            fechanac = '".$fechanac."',
            estadonac = ".$estadonac.",
            munnac = ".$municipionac.",
            direccion = '".$calle."',
            numeroext = '".$numcalle."',
            colonia = '".$col."',
            cp = '".$cp."',
            estact = ".$estadoact.",
            munact = ".$municipioact.",
            telefonofijo = '".$telfijo."',
            cel = '".$cel."',
            correo = '".$correo."',
            estproc = ".$estadoproc.",
            munproc = ".$municipioproc.",
            escuelaproc = ".$escuela.",
            egreso = '".$egresoesc."',
            prom = ".$prom.",
            rfc = '".$rfc."',
            fullregistro = 2
            WHERE id = ".$id;

    sql2($db, $query);

    echo "<meta http-equiv='refresh' content='0;url=/'>";

}

if(isset($_POST['datospersonales'])){
    $query = "UPDATE aspirantes SET 
        
            nombre = '".$nom."',
            paterno = '".$pat."',
            materno = '".$mat."',
            fechanac = '".$fechanac."',
            estadonac = ".$estadonac.",
            munnac = ".$municipionac.",
            telefonofijo = '".$telfijo."',
            cel = '".$cel."',
            correo = '".$correo."',
            rfc = '".$rfc."'
            
            
            WHERE id = ".$id;

    sql2($db, $query);

    echo "<meta http-equiv='refresh' content='0;url=/'>";
}

if(isset($_POST['mcurp'])){
    $query = "UPDATE aspirantes SET 
            curp = '".$mocurp."'
            WHERE id = ".$id;

    sql2($db, $query);

    echo "<meta http-equiv='refresh' content='0;url=/'>";

}

if(isset($_POST['domactual'])){
    $query = "UPDATE aspirantes SET 
          
            direccion = '".$calle."',
            numeroext = '".$numcalle."',
            colonia = '".$col."',
            cp = '".$cp."',
            estact = ".$estadoact.",
            munact = ".$municipioact."
            
            WHERE id = ".$id;

    sql2($db, $query);

    echo "<meta http-equiv='refresh' content='0;url=/'>";

}

if(isset($_POST['procedencia'])){
    $query = "UPDATE aspirantes SET 
          
            estproc = ".$estadoproc.",
            munproc = ".$municipioproc.",
            escuelaproc = ".$escuela.",
            egreso = '".$egresoesc."',
            prom = ".$prom."
            WHERE id = ".$id;

    sql2($db, $query);

    echo "<meta http-equiv='refresh' content='0;url=/'>";

}

if (isset($_POST['preficha'])) {
    $preficha = $_POST['carrera'] . "17" . "15" . $_SESSION['info']['id'];
    $query = "UPDATE aspirantes SET careleg = '" . $_POST['carrera'] . "', aspirantecve = '" . $preficha . "' WHERE id = " . $_SESSION['info']['id'];
    sql2($db, $query);
    //$_SESSION['info']['aspirantecve'] = $preficha;

    $rows3 = asignar($db, $_SESSION['info']['id']);
    foreach ($rows3 as $row2) {}

    date_default_timezone_set('America/Mexico_City');
    $date = date('d/m/Y', time());

    $consecutivo = $row2['asignadas'];

    $r = new referencia_pago($preficha, 'A003007000001', $consecutivo, $date, '00065000');
    $numa = $r->main();
    $query2 = "UPDATE aspirantes SET referencia = '" . $numa . "' WHERE id = " . $_SESSION['info']['id'];
    sql2($db, $query2);
    $date3 = date('Ymd', time());
    $date2 = date('Ymd', strtotime($date3. ' + 15 days'));
    $rip = 0;
    $query3 = "INSERT INTO pagos VALUES(NULL,'".$numa."','".$preficha."',$date3,$date2,$rip)";
    sql2($db, $query3);

    //$_SESSION['info']['referencia'] = $numa;*/
    echo "<meta http-equiv='refresh' content='0;url=/'>";



}

