<?php
session_start();
?>
<!DOCTYPE html>
<div class="lolazo">
    <html lang="es">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Login">
        <meta name="author" content="Iván Gerardo Caldera Hermosillo, Rene Lee Ramirez">
        <title>Sistema de Fichas</title>
        <link href="_include/CSS/bootstrap.min.css" rel="stylesheet">
        <link href="_include/CSS/login.css" rel="stylesheet">
        <link href="_include/frameworks/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="_include/CSS/bootstrap-dialog.min.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
    <div id="wrapper">
        <div id="page-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-md-offset-7">
                        <div id="registrodiv"class="panel panel-default">
                            <div class="panel-heading">
                                Ingresa tu Información
                            </div>
                            <div class="panel-body">
                                <form class="form-horizontal form-registro" role="form" method="post">
                                    <div class="form-group">
                                        <label for="pat" class="col-sm-3 control-label">
                                            Apellido Paterno
                                        </label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" style="text-transform: uppercase" id="pat" name="pat" placeholder="ej: López" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="mat" class="col-sm-3 control-label">
                                            Apellido Materno
                                        </label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" style="text-transform: uppercase" id="mat" name="mat" placeholder="ej: Gonzalez" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="nom" class="col-sm-3 control-label">
                                            Nombre(s):
                                        </label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" style="text-transform: uppercase" id="nom" name="nom" placeholder="ej: Juan Raúl" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="dia" class="col-sm-3 control-label">
                                            Fecha de nacimiento:
                                        </label>
                                        <div class="col-sm-9">
                                            <select  class="selectpicker" id="dia" name="dia">
                                                <option value="01">01</option>
                                                <option value="02">02</option>
                                                <option value="03">03</option>
                                                <option value="04">04</option>
                                                <option value="05">05</option>
                                                <option value="06">06</option>
                                                <option value="07">07</option>
                                                <option value="08">08</option>
                                                <option value="09">09</option>
                                                <option value="10">10</option>
                                                <option value="11">11</option>
                                                <option value="12">12</option>
                                                <option value="13">13</option>
                                                <option value="14">14</option>
                                                <option value="15">15</option>
                                                <option value="16">16</option>
                                                <option value="17">17</option>
                                                <option value="18">18</option>
                                                <option value="19">19</option>
                                                <option value="20">20</option>
                                                <option value="21">21</option>
                                                <option value="22">22</option>
                                                <option value="23">23</option>
                                                <option value="24">24</option>
                                                <option value="25">25</option>
                                                <option value="26">26</option>
                                                <option value="27">27</option>
                                                <option value="28">28</option>
                                                <option value="29">29</option>
                                                <option value="30">30</option>
                                                <option value="31">31</option>
                                            </select>
                                            <select  class="selectpicker" id="mes" name="mes">
                                                <option value="01">ENE</option>
                                                <option value="02">FEB</option>
                                                <option value="03">MAR</option>
                                                <option value="04">ABR</option>
                                                <option value="05">MAY</option>
                                                <option value="06">JUN</option>
                                                <option value="07">JUL</option>
                                                <option value="08">AGO</option>
                                                <option value="09">SEP</option>
                                                <option value="10">OCT</option>
                                                <option value="11">NOV</option>
                                                <option value="12">DIC</option>
                                            </select>
                                            <select  class="selectpicker" id="anio" name="anio">
                                                <option value="1951">1951</option>
                                                <option value="1952">1952</option>
                                                <option value="1953">1953</option>
                                                <option value="1954">1954</option>
                                                <option value="1955">1955</option>
                                                <option value="1956">1956</option>
                                                <option value="1957">1957</option>
                                                <option value="1958">1958</option>
                                                <option value="1959">1959</option>
                                                <option value="1960">1960</option>
                                                <option value="1961">1961</option>
                                                <option value="1962">1962</option>
                                                <option value="1963">1963</option>
                                                <option value="1964">1964</option>
                                                <option value="1965">1965</option>
                                                <option value="1966">1966</option>
                                                <option value="1967">1967</option>
                                                <option value="1968">1968</option>
                                                <option value="1969">1969</option>
                                                <option value="1970">1970</option>
                                                <option value="1971">1971</option>
                                                <option value="1972">1972</option>
                                                <option value="1973">1973</option>
                                                <option value="1974">1974</option>
                                                <option value="1975">1975</option>
                                                <option value="1976">1976</option>
                                                <option value="1977">1977</option>
                                                <option value="1978">1978</option>
                                                <option value="1979">1979</option>
                                                <option value="1980">1980</option>
                                                <option value="1981">1981</option>
                                                <option value="1982">1982</option>
                                                <option value="1983">1983</option>
                                                <option value="1984">1984</option>
                                                <option value="1985">1985</option>
                                                <option value="1986">1986</option>
                                                <option value="1987">1987</option>
                                                <option value="1988">1988</option>
                                                <option value="1989">1989</option>
                                                <option value="1990">1990</option>
                                                <option value="1991">1991</option>
                                                <option value="1992">1992</option>
                                                <option value="1993">1993</option>
                                                <option value="1994">1994</option>
                                                <option value="1995">1995</option>
                                                <option value="1996">1996</option>
                                                <option value="1997">1997</option>
                                                <option value="1998">1998</option>
                                                <option value="1999">1999</option>
                                                <option value="2000">2000</option>
                                                <option value="2001">2001</option>
                                                <option value="2002">2002</option>
                                                <option value="2003">2003</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="estado" class="col-sm-3 control-label">
                                            Lugar de nacimiento:</label>
                                        <div class="col-sm-9">
                                            <select name="estado" id="estado" class="required" required>
                                                <option value="">Elige tu Estado de Nacimiento</option>
                                                <option value="AS">AGUASCALIENTES</option>
                                                <option value="BC">BAJA CALIFORNIA</option>
                                                <option value="BS">BAJA CALIFORNIA SUR</option>
                                                <option value="CC">CAMPECHE</option>
                                                <option value="CS">CHIAPAS</option>
                                                <option value="CH">CHIHUAHUA</option>
                                                <option value="CL">COAHUILA</option>
                                                <option value="CM">COLIMA</option>
                                                <option value="DF">DISTRITO FEDERAL</option>
                                                <option value="DG">DURANGO</option>
                                                <option value="GT">GUANAJUATO</option>
                                                <option value="GR">GUERRERO</option>
                                                <option value="HG">HIDALGO</option>
                                                <option value="JC">JALISCO</option>
                                                <option value="MC">MEXICO</option>
                                                <option value="MS">MORELOS</option>
                                                <option value="MN">MICHOACAN</option>
                                                <option value="NT">NAYARIT</option>
                                                <option value="NL">NUEVO LEON</option>
                                                <option value="OC">OAXACA</option>
                                                <option value="PL">PUEBLA</option>
                                                <option value="QT">QUERETARO</option>
                                                <option value="QR">QUINTANA ROO</option>
                                                <option value="SP">SAN LUIS POTOSI</option>
                                                <option value="SL">SINALOA</option>
                                                <option value="SR">SONORA</option>
                                                <option value="TC">TABASCO</option>
                                                <option value="TS">TAMAULIPAS</option>
                                                <option value="TL">TLAXCALA</option>
                                                <option value="VZ">VERACRUZ</option>
                                                <option value="YN">YUCATAN</option>
                                                <option value="ZS">ZACATECAS</option>
                                                <option value="NE">EXTRANJERO</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="sexo" class="col-sm-3 control-label">
                                            Sexo:
                                        </label>
                                        <div class="col-sm-9">
                                            <select name="sexo" id="sexo" class="control required" required>
                                                <option selected="selected" value="">Elige una opción</option>
                                                <option value="H">Hombre</option>
                                                <option value="M">Mujer</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group last">
                                        <div class="col-sm-offset-7 col-sm-9">
                                            <button id="registro" name="registro" type="button" onclick="confirm()" class="btn btn-success btn-lg">
                                                Aceptar
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="panel-footer">
                                <h4> ¿Ya te Registraste?
                                    <a id="loginbut" href="#">
                                        Haz click aquí.
                                    </a>
                                </h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-md-offset-7">
                        <div id="logindiv" class="panel panel-default">
                            <div class="panel-heading">
                                Ingresa tu Información
                            </div>
                            <div class="panel-body">
                                <form class="form-horizontal form-login" role="form" method="post">
                                    <div class="form-group">
                                        <label for="pat" class="col-sm-3 control-label">
                                            CURP
                                        </label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" maxlength="18" style="text-transform: uppercase" id="curp" name="curp" placeholder="" required autofocus>
                                        </div>
                                    </div>
                                    <div class="form-group last">
                                        <div class="col-sm-offset-7 col-sm-9">
                                            <button id="login" name="login" type="submit" class="btn btn-success ">
                                                Aceptar
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="panel-footer">
                                <h4>¿No estás Registrado?
                                    <a id="registrobut" href="#">Haz click aquí.</a>
                                </h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="_include/JS/divs.js"></script>
    <script src="_include/JS/jquery.js"></script>
    <script src="_include/JS/curp.js"></script>
    <script src="_include/JS/index.js"></script>
    <script src="_include/JS/bootstrap.min.js"></script>
    <script src="_include/JS/bootstrap-dialog.min.js"></script>
    <script src="_include/JS/jquery.validate.js"></script>

    </body>
    </html>
</div>