(function()
{
    document.getElementById("loginbut").onclick = function()
    {
        if (document.getElementById('registrodiv'))
        {

            if (document.getElementById('registrodiv').style.display == 'none')
            {
                document.getElementById('resgitrodiv').style.display = 'block';
                document.getElementById('logindiv').style.display = 'none';
            }
            else
            {
                document.getElementById('registrodiv').style.display = 'none';
                document.getElementById('logindiv').style.display = 'block';
            }
        }
    };
})();

(function()
{
    document.getElementById("registrobut").onclick = function()
    {
        if (document.getElementById('logindiv'))
        {

            if (document.getElementById('logindiv').style.display == 'none')
            {
                document.getElementById('logindiv').style.display = 'block';
                document.getElementById('resgitrodiv').style.display = 'none';
            }
            else
            {
                document.getElementById('logindiv').style.display = 'none';
                document.getElementById('registrodiv').style.display = 'block';
            }
        }
    };
})();




function confirm() {

    if($('#pat').valid() && $('#mat').valid() && $('#nom').valid() && $('#estado').valid() && $('#sexo').valid()) {

        var curp = generaCurp({
            nombre: document.getElementById("nom").value,
            apellido_paterno: document.getElementById("pat").value,
            apellido_materno: document.getElementById("mat").value,
            sexo: document.getElementById("sexo").value,
            estado: document.getElementById("estado").value,
            fecha_nacimiento: [document.getElementById("dia").value, document.getElementById("mes").value, document.getElementById("anio").value]
        });
        var $confirmadiv = $('<form class="form-horizontal form-confirmacion" role="form" method="post"></form>');
        $confirmadiv.append('<p class="box box-info">' +
            '<p align="justify"><h4>Es importante que verifiques tus datos antes de registrarte de lo contrario podrías generar una ficha no válida.</h4></p>' +
            '<div class="col-sm-5 col-xs-6 tital " >Apellido Paterno:</div><div class="col-sm-7" style="text-transform: uppercase; font-style: italic; font-weight: bold;" >' + document.getElementById("pat").value + '</div>' +
            '<div class="clearfix"></div>' +
            '<div class="bot-border"></div>' +
            '<div class="col-sm-5 col-xs-6 tital " >Apellido Materno:</div><div class="col-sm-7" style="text-transform: uppercase; font-style: italic; font-weight: bold;">' + document.getElementById("mat").value + '</div>' +
            '<div class="clearfix"></div>' +
            '<div class="bot-border"></div>' +
            '<div class="col-sm-5 col-xs-6 tital " >Nombre(s):</div><div class="col-sm-7" style="text-transform: uppercase; font-style: italic; font-weight: bold;">' + document.getElementById("nom").value + '</div>' +
            '<div class="clearfix"></div>' +
            '<div class="bot-border"></div>' +
            '<div class="col-sm-5 col-xs-6 tital " >Fecha de nacimiento:</div><div class="col-sm-7" style="text-transform: uppercase; font-style: italic; font-weight: bold;">' + document.getElementById("dia").value + '/' + document.getElementById("mes").value + '/' + document.getElementById("anio").value + '</div>' +
            '<div class="clearfix"></div>' +
            '<div class="bot-border"></div>' +
            '<div class="col-sm-5 col-xs-6 tital " >Lugar de Nacimiento:</div><div class="col-sm-7" style="text-transform: uppercase; font-style: italic; font-weight: bold;">' + $("#estado option:selected").text() + '</div>' +
            '<div class="clearfix"></div>' +
            '<div class="bot-border"></div>' +
            '<div class="col-sm-5 col-xs-6 tital " >Sexo:</div><div class="col-sm-7" style="text-transform: uppercase; font-style: italic; font-weight: bold;">' + $("#sexo option:selected").text() + '</div>' +
            '<div class="clearfix"></div>' +
            '<div class="bot-border"></div>' +
            '<div class="clearfix"></div>' +
            '<div class="bot-border"></div>' +
            '<hr/>' +
            '<p align="justify"><h3><strong>Nota Importante:</strong></h3> Tu clave CURP es la información más importante para tu registro, con ella podrás volver accesar al sistema de fichas.</p>' +
            '<p>Puedes consultar tu CURP haciendo click <a href="https://consultas.curp.gob.mx/CurpSP/inicio2_2.jsp">aquí.</a></p>' +
            '<p align="justify">A continuación podrás modificar tu clave si encuentras un error en ella, si no, déjala como está.</p>' +
            '<div class="col-sm-5 col-xs-6 tital " >CURP:</div><div class="col-sm-7" style="text-transform: uppercase; font-style: italic; font-weight: bold;" ><input type="text" class="form-control" style="text-transform: uppercase" id="lacurp" pattern="[a-zA-Z0-9-]+" maxlength="18" name="lacurp" value="' + curp + '" required></div>' +
            '<div class="clearfix"></div>' +
            '<div class="bot-border"></div>' +
            '</div>');


        BootstrapDialog.show({
            title: 'Porfavor, confirma tus datos',
            message: $confirmadiv,
            buttons: [{
                icon: 'fa fa-fw fa-edit',
                label: 'Registrarme',
                cssClass: 'btn-primary',
                id: 'confirmar',
                action: function (dialogRef) {
                    if ($('#lacurp').valid()) {
                        var curp2 = document.getElementById("lacurp").value;
                        dialogRef.enableButtons(false);
                        dialogRef.setClosable(false);
                        dialogRef.getModalBody().html('Registrando...');
                        var datos =
                            {
                                'accion': 'reg',
                                'curp': curp2,
                                'nombre': document.getElementById("nom").value,
                                'pat': document.getElementById("pat").value,
                                'mat': document.getElementById("mat").value,
                                'estado': document.getElementById("estado").value,
                                'fechanac': document.getElementById("dia").value + '/' + document.getElementById("mes").value + '/' + document.getElementById("anio").value
                            };

                        $.ajax
                        ({
                            type: "POST",
                            dataType: "json",
                            url: "_include/PHP/index.php",
                            data: datos,
                            success: function (datos) {
                                if (datos['respuesta']) {
                                    dialogRef.close();
                                    $(".lolazo").load('_include/PHP/fichas.php');
                                }
                                else {
                                    alert('Ya se tiene una persona registrada con estos datos, intenta entrar al sistema con tu CURP');
                                    dialogRef.close();
                                }
                            }
                        });
                        return false;
                    }
                }

            }, {
                label: 'Cerrar Ventana',
                action: function (dialogRef) {
                    dialogRef.close();
                }
            }]

        });
    }
}








