
    document.getElementById("modifica").onclick = function () {
        BootstrapDialog.show({
            title: 'Modifica tus Datos',
            message: $('<div></div>').load('_include/PHP/modificaDatos.php')
        });
    };
    document.getElementById("modificaLink").onclick = function () {
        BootstrapDialog.show({
            title: 'Modifica tus Datos',
            message: $('<div></div>').load('_include/PHP/modificaDatos.php')
        });
    };








