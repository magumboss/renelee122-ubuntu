/**
 * Created by magumbo on 3/23/17.
 */
$(function() {

    $('.estadonac').change(function() {
        var select = $('.municipionac').empty();
        $.get('_include/PHP/traeMunicipios.php', {estcve: document.getElementById("estadonac").value}, function(estcve) {
            $('<option value="">Elige una opción</option>').
            appendTo(select);
            $.each(JSON.parse(estcve), function(i, item) {
                $('<option value="' + item.munid + '">' + item.munnom + '</option>').
                appendTo(select);
            });
        });
    });
});

$(function() {

    $('.estadoact').change(function() {
        var select = $('.municipioact').empty();
        $.get('_include/PHP/traeMunicipios.php', {estcve: document.getElementById("estadoact").value}, function(estcve) {
            $('<option value="">Elige una opción</option>').
            appendTo(select);
            $.each(JSON.parse(estcve), function(i, item) {
                $('<option value="' + item.munid + '">' + item.munnom + '</option>').
                appendTo(select);
            });
        });
    });
});

$(function() {

    $('.estadoproc').change(function() {
        var select = $('.municipioproc').empty();
        $.get('_include/PHP/traeMunicipios.php', {estcve: document.getElementById("estadoproc").value}, function(estcve) {
            $('<option value="">Elige una opción</option>').
            appendTo(select);
            $.each(JSON.parse(estcve), function(i, item) {
                $('<option value="' + item.munid + '">' + item.munnom + '</option>').
                appendTo(select);
            });
        });
    });
});

$('.municipioproc').change(function() {
    var select = $('.escuela').empty();
    $.get('_include/PHP/traeEscuelas.php', {estcve: document.getElementById("estadoproc").value, muncve: document.getElementById("municipioproc").value}, function(estcve) {
        $('<option value="">Elige una opción</option>').
        appendTo(select);

        $.each(JSON.parse(estcve), function(i, item) {
            $('<option value="' + item.esccve + '">' + item.escnom + '</option>').
            appendTo(select);
        });

    });
});

$("#telfijo").keypress( function(e) {
    var chr = String.fromCharCode(e.which);
    if ("1234567890".indexOf(chr) < 0)
        return false;
});
$("#cel").keypress( function(e) {
    var chr = String.fromCharCode(e.which);
    if ("1234567890".indexOf(chr) < 0)
        return false;
});
$("#cp").keypress( function(e) {
    var chr = String.fromCharCode(e.which);
    if ("1234567890".indexOf(chr) < 0)
        return false;
});
$("#numcalle").keypress( function(e) {
    var chr = String.fromCharCode(e.which);
    if ("1234567890".indexOf(chr) < 0)
        return false;
});

$("#mocurp").keypress( function(e) {
    var chr = String.fromCharCode(e.which);
    if ("1234567890QWERTYUIOPASDFGHJKLZXCVBNM".indexOf(chr) < 0)
        return false;
});


