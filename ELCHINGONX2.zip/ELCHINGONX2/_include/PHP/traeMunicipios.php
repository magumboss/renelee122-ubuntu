<?php
/**
 * Created by PhpStorm.
 * User: magumbo
 * Date: 3/22/17
 * Time: 5:55 PM
 */

include ("config.php");

if (isset($_GET['estcve'])) {

    $estcve = $_GET['estcve'];
    $query = "SELECT muncve,munnom FROM municipios WHERE estcve = $estcve";


    $rows = sql($db, $query, "rows");

    foreach($rows as $row) {
        $result[] = array(
            'munid' => $row['muncve'],
            'munnom' => $row['munnom']
        );
    }


    echo json_encode($result);
}