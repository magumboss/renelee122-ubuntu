<?php
include ("Resultados.php") ;
$Resultados = new Resultados();
if (is_ajax()) {
  if (isset($_POST["accion"]) && !empty($_POST["accion"])) {
    $action = $_POST["accion"];
    switch($action) {
      case "login": funcion_login(); break;
      case "reg": funcion_registro(); break;
    }
  }
}
function is_ajax(){
  return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
}
function funcion_login(){
   global $Resultados;
  $response = ['respuesta' => $Resultados -> getLog( $_POST['curp'])];
  if ($response['respuesta']){
      session_start();
      $_SESSION['CURP'] = $_POST['curp'];
  }
  echo json_encode($response);
}
function funcion_registro(){
    global $Resultados;
    try
    {
        $Resultados -> setReg( $_POST['curp'], $_POST['nombre'], $_POST['pat'], $_POST['mat'], $_POST['estado'], $_POST['fechanac']);
        session_start();
        $_SESSION['CURP'] = $_POST['curp'];
        $_SESSION['registro'] = 1;
        $response = ['respuesta' => true ];
    }
    catch(Exception $e)
    {
        $response = ['respuesta' => false ];
    }
    echo json_encode($response);
}
?>