<?php
class Connection
{
    private $Connection = null;
    public function __construct()
    {
        try
        {
            $this -> Connection = new PDO
            (
                'mysql:host=127.0.0.1;dbname=fichas',
                'majumbo',
                '12345'
            );
            $this -> Connection -> setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
        }
        catch(PDOException $e)
        {
            echo "Connection failed: " . $e -> getMessage();
        }
    }
    public function getConnection()
    {
        return $this -> Connection;
    }
}
?>