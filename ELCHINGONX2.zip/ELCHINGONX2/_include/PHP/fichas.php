<?php
include ("config.php");
include ("ref.php");
if(isset($_GET['Cerrar']))
{
    session_start();
    session_destroy();
    echo "<meta http-equiv='refresh' content='0;url=/'>";
}
else
{
    session_start();
    if (!isset($_SESSION['CURP']))
    {
        echo "<meta http-equiv='refresh' content='0;url=/'>";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="creacion de fichas">
        <meta name="author" content="Iván Gerardo Caldera Hermosillo, Rene Lee Ramirez">
        <title>Sistema de Fichas</title>
        <link href="_include/CSS/bootstrap.min.css" rel="stylesheet">
        <link href="_include/CSS/sb-admin.css" rel="stylesheet">
        <link href="_include/CSS/bootstrap-dialog.min.css" rel="stylesheet" type="text/css" />
        <link href="_include/frameworks/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>

    </head>
    <body>
    <div id="wrapper">
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="/">TECNM - ITA</a>
            </div>
            <ul class="nav navbar-right top-nav">
                <li>
                    <a href="_include/PHP/fichas.php?Cerrar=1" ><i class="fa fa-sign-out"></i> Cerrar Sesión </a>
                </li>
            </ul>
            <div class="collapse navbar-collapse navbar-ex1-collapse">
            <?php
            include ("sideMenu.php");
            include ("datosPersonales.php");
            ?>

    </div>



    </body>



    <script src="_include/JS/bootstrap-dialog.min.js"></script>
</html>