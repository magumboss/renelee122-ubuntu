<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
/**
 * Created by PhpStorm.
 * User: magumbo
 * Date: 3/21/17
 * Time: 3:28 PM
 */

if (!isset($_SESSION['CURP']))
{
    echo "<meta http-equiv='refresh' content='0;url=/'>";
}
if ($_SESSION['CURP'] != $_SESSION['info']['curp']) {
    $query = "SELECT id, curp, nombre, paterno, materno, fechanac, direccion, numeroext, colonia, cp, estact, telefonofijo, cel, correo, estproc, munproc, escuelaproc, careleg, aspirantecve, referencia, fullregistro FROM aspirantes WHERE curp = '" . $_SESSION['CURP'] . "'";
    $rows = sql($db, $query, "rows");
    foreach ($rows as $_SESSION['info']) {
    }
    $_SESSION['CURP'] = $_SESSION['info']['curp'];
}else{
    $query = "SELECT id, curp, nombre, paterno, materno, fechanac, direccion, numeroext, colonia, cp, estact, telefonofijo, cel, correo, estproc, munproc, escuelaproc, careleg, aspirantecve, referencia, fullregistro FROM aspirantes WHERE id = ".$_SESSION['info']['id'];
    $rows = sql($db, $query, "rows");
    foreach ($rows as $_SESSION['info']) {
    }
    $_SESSION['CURP'] = $_SESSION['info']['curp'];
}

if(!empty($_SESSION['info']['referencia'])){
    $queryfechas = "SELECT fecha, fechavig FROM pagos WHERE referencia = '".$_SESSION['info']['referencia']."'";
    $rowsfechas = sql6($db, $queryfechas);
    foreach ($rowsfechas as $rowfechas) {}
    $_SESSION['fecha'] =  date("d-m-Y", strtotime($rowfechas['fecha']));
    $_SESSION['fechavig'] = date("d-m-Y", strtotime($rowfechas['fechavig']));
    $_SESSION['fechavigraw'] = strtotime($rowfechas['fechavig']);
}else{
    $_SESSION['fecha'] = "";
    $_SESSION['fechavig'] = "";
}
    echo '
        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h3>
                        Datos Generales
                        </h3>
                        <hr/>';
if($_SESSION['info']['fullregistro'] == 1){
    echo'                    
                    <div class="alert alert-warning">
                          <strong>¡Atención!</strong> Necesitamos que registres tu infomación completa antes de generar tu ficha, haz click sobre el botón "Registrar Información".
                    </div>
                        
                        ';
}
if($_SESSION['info']['referencia'] == "" && $_SESSION['info']['fullregistro'] > 1){
    echo'                    
                    <div class="alert alert-success">
                          Selecciona la carrera de tu elección para generar tu ficha y recibo de pago.
                    </div>
                        
                        ';
}
if(!empty($_SESSION['info']['referencia'])) {
    if ($_SESSION['fechavigraw'] < time()) {
        echo '                    
                    <div class="alert alert-danger">
                          La fecha límite para pagar se ha rebasado, selecciona nuevamente una carrera para generar un nuevo recibo de pago.
                    </div>
                        
                        ';
        $query = "UPDATE aspirantes SET careleg=NULL,aspirantecve ='', referencia = '' WHERE referencia = '" . $_SESSION['info']['referencia'] . "'";
        $rowsfechas = sql2($db, $query);
        $_SESSION['info']['referencia'] = "";
        $_SESSION['info']['aspirantecve'] = "";
        $_SESSION['info']['careleg'] = "";
    }
}
if(!empty($_SESSION['info']['estact'])) {
    $rowsest = estados($db, $_SESSION['info']['estact']);
    foreach ($rowsest as $rowest) {}
}else{
    $rowest['estnom'] = "";
}

if(!empty($_SESSION['info']['escuelaproc'])) {
    $rowsesc = escuelas($db, $_SESSION['info']['estproc'], $_SESSION['info']['munproc'], $_SESSION['info']['escuelaproc']);
    foreach ($rowsesc as $rowesc) {
    }
}else{
    $rowesc['escnom'] = "";
}



 echo'                       </div>
                        </div>
                        <div class="row">     
       <div class="col-md-6 ">

<div class="panel panel-default">
  <div class="panel-heading">  <i class = "fa fa-fw fa-info"></i> Información del Aspirante</div>
   <div class="panel-body">
       
    <div class="box box-info">     

			<div class="col-sm-5 col-xs-6 tital " >Clave CURP:</div><div class="col-sm-7" style="font-style: italic; font-weight: bold;">
			' . $_SESSION['info']['curp'] . '</div>

			  <div class="clearfix"></div>
			<div class="bot-border"></div>

			<div class="col-sm-5 col-xs-6 tital " >Nombre:</div><div class="col-sm-7" style="text-transform: uppercase"> ' . $_SESSION['info']['nombre'] .' '. $_SESSION['info']['paterno'].' '.$_SESSION['info']['materno'].'</div>

			  <div class="clearfix"></div>
			<div class="bot-border"></div>

			<div class="col-sm-5 col-xs-6 tital " >Fecha de Nacimiento:</div><div class="col-sm-7">' . $_SESSION['info']['fechanac'] .' </div>

			 <div class="clearfix"></div>
			<div class="bot-border"></div>

			<div class="col-sm-5 col-xs-6 tital " >Domicilio:</div><div class="col-sm-7"> ' . $_SESSION['info']['direccion'] . ' #' . $_SESSION['info']['numeroext'] .' </div>

			 <div class="clearfix"></div>
			<div class="bot-border"></div>

			<div class="col-sm-5 col-xs-6 tital " >Colonia:</div><div class="col-sm-7"> ' . $_SESSION['info']['colonia'] .'</div>
			
			<div class="clearfix"></div>
			<div class="bot-border"></div>

			<div class="col-sm-5 col-xs-6 tital " >Estado:</div><div class="col-sm-7"> ' . $rowest['estnom'] .'</div>
			
			<div class="clearfix"></div>
			<div class="bot-border"></div>

			<div class="col-sm-5 col-xs-6 tital " >C.P.:</div><div class="col-sm-7"> ' . $_SESSION['info']['cp'] .'</div>
			
			<div class="clearfix"></div>
			<div class="bot-border"></div>

			<div class="col-sm-5 col-xs-6 tital " >Teléfono Fijo:</div><div class="col-sm-7"> ' . $_SESSION['info']['telefonofijo'] .'</div>
			
			<div class="clearfix"></div>
			<div class="bot-border"></div>

			<div class="col-sm-5 col-xs-6 tital " >Teléfono Celular:</div><div class="col-sm-7"> ' . $_SESSION['info']['cel'] .'</div>
			
			<div class="clearfix"></div>
			<div class="bot-border"></div>

			<div class="col-sm-5 col-xs-6 tital " >Correo Electrónico:</div><div class="col-sm-7"> ' . $_SESSION['info']['correo'] .'</div>
			
			<div class="clearfix"></div>
			<div class="bot-border"></div>


			<div class="col-sm-5 col-xs-6 tital " >Escuela de Procedencia:</div><div class="col-sm-7"> '.$rowesc['escnom'].'</div>
			
			<div class="clearfix"></div>
			<div class="bot-border"></div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div>
       
            
    </div> 

                </div>

                <div class="col-md-6 ">';
if ($_SESSION['info']['fullregistro'] != 1) {


    echo '<div class="panel panel-primary">';


    echo '<div class="panel-heading">  <i class = "fa fa-fw fa-info"></i> Datos de Ficha</div>
   <div class="panel-body">
       
    <div class="box box-info">     

			

			<div class="col-sm-5 col-xs-6 tital " >Carrera a Elegir:</div><div class="col-sm-7">';





    if (empty($_SESSION['info']['aspirantecve'])) {

        echo '
			<form class="form-horizontal form-preficha" role="form" method="post" action="_include/PHP/registros.php">
			<select style="width: 70%" name="carrera" id="carrera" class="selectpicker" required>
			                        <option value="">Elige Carrera</option>
                                    <option value="1">INGENIERÍA QUÍMICA</option>
                                    <option value="2">INGENIERÍA MECÁNICA</option>
                                    <option value="3">INGENIERÍA ELECTRÓNICA</option>
                                    <option value="4">INGENIERÍA ELÉCTRICA</option>
                                    <option value="5">INGENIERÍA INDUSTRIAL</option>
                                    <option value="6">LICENCIATURA EN ADMINISTRACIÓN</option>
                                    <option value="7">INGENIERÍA EN GESTIÓN EMPRESARIAL</option>
                                    <option value="8">INGENIERÍA EN TECNOLOGÍAS DE LA INFORMACIÓN Y COMUNICACIONES</option>
                                    <option value="9">INGENIERÍA EN MATERIALES</option>          
                                </select>
                                <button id="preficha" name="preficha" type="submit" class="btn btn-success btn-sm">Aceptar</button>
                                </form>';
    } else {
        $rows2 = carreras($db, $_SESSION['info']['careleg']);


        foreach ($rows2 as $row) {}
        echo $row['nombre'];
        $_SESSION['nomcarrera'] = $row['nombre'];


    }


    echo '
                                
			</div>
			
			<div class="clearfix"></div>
			<div class="bot-border"></div>

			<div class="col-sm-5 col-xs-6 tital " >Ficha:</div><div class="col-sm-7 pull-left" > ' . $_SESSION['info']['id'] . '</div>
			
			<div class="clearfix"></div>
			<div class="bot-border"></div>

			<div class="col-sm-5 col-xs-6 tital " >Fecha de creación de la Ficha:</div><div class="col-sm-7"> ' . $_SESSION['fecha']. '</div>
			
			


            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div>
       
            
    </div> ';

    if(!$_SESSION['info']['careleg'] == "") {

        echo ' 
    <div class="panel panel-danger">
  <div class="panel-heading">  <i class = "fa fa-fw fa-bank"></i> Información para la Realización del Pago</div>
   <div class="panel-body">
       
    <div class="box box-info">     

			

			<div class="col-sm-5 col-xs-6 tital " >Banco y Cuenta:</div><div class="col-sm-7"> Banorte 13126</div>
			
			<div class="clearfix"></div>
			<div class="bot-border"></div>

			<div class="col-sm-12 col-xs-6  tital" >Número de Referencia:</div>
			
			<div class="clearfix"></div>
			
			<div class="col-sm-5 col-xs-6" style="font-size: 80%;">' . $_SESSION['info']['referencia'] . '</div>
			
			<div class="clearfix"></div>
			<div class="bot-border"></div>

			<div class="col-sm-5 col-xs-6 tital " >Pagar antes del:</div><div class="col-sm-7"><strong>'.$_SESSION['fechavig'].'</strong></div>
			
			<div class="clearfix"></div>
			<div class="bot-border"></div>
            <div class="col-sm-5 col-md-offset-1 tital " >
			
                    </div>


            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div>
       
            
    </div> 
    
      <div class="col-md-6">
               
                        <div class="panel panel-green">
                        
                            <div class="panel-heading">
                            <a href="_include/PHP/imprimirPDF.php" style="color: white">
                                <div class="row">
                                    <div class="col-xs-offset-4">
                                        <i class="fa fa-print fa-5x"></i>
                                    </div>
                                   
                                </div>
                                </a>
                            </div>
                            <a href="_include/PHP/imprimirPDF.php">
                                <div class="panel-footer">
                                    <span class="pull-left">Imprimir Pago de Examen</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>';
    }

    echo '
                    
                    
                    
                     <div class="col-md-6">
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                            <a id="modifica" href="#" style="color: white">
                                <div class="row">
                                    <div class="col-xs-offset-4">
                                        <i class="fa fa-edit fa-5x"></i>
                                    </div>
                                    
                                </div>
                                </a>
                            </div>
                            <a id="modificaLink" href="#" >
                                <div class="panel-footer">
                                    <span class="pull-left">Modificar Información</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <script src="_include/JS/modifica.js"></script>';

}else{

    echo '
                    
                    
                    
                     <div class="col-md-6">
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                            <a id="modificafull" href="#" style="color: white">
                                <div class="row">
                                    <div class="col-xs-offset-4">
                                        <i class="fa fa-edit fa-5x"></i>
                                    </div>
                                    
                                </div>
                                </a>
                            </div>
                            <a id="modificafullLink" href="#" >
                                <div class="panel-footer">
                                    <span class="pull-left">Registrar Información</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <script src="_include/JS/modifica2.js"></script>
                 ';
}

echo'

                </div>
                </div>
                       
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->
       
        </div>
        <!-- /#page-wrapper -->
       
        
      

    
';

