<?php
	include "Connection.php";
	class Resultados extends Connection{
		private $Connection = null;
		private $SQL = null;
		public function __construct(){
			parent::__construct();
			$this -> Connection = parent::getConnection();
			$this -> SQL = array(

				"SELECT curp FROM aspirantes WHERE curp = :curp;",
				"INSERT INTO aspirantes VALUES (null, :curp, :nombre, :pat, :mat, :fechanac, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, :full);"
            );
		}
		public function getLog($curp){
			$login = $this -> Connection -> prepare($this -> SQL[0]);
			$login -> bindParam(':curp', $curp, PDO::PARAM_STR);
			$login -> execute();
			return ($login -> fetch(PDO::FETCH_NUM) != null);
		}
		/*public function setLog($name, $lastname, $secondarylastname, $birthday, $address, $extnumber, $intnumber, $phonenumber, $zipcode, $email, $curp){
			$signin = $this -> Connection -> prepare($this -> SQL[1]);
			$signin -> bindParam(':name', $name, PDO::PARAM_STR);
			$signin -> bindParam(':lastname', $lastname, PDO::PARAM_STR);
			$signin -> bindParam(':secondarylastname', $secondarylastname, PDO::PARAM_STR);
			$signin -> bindParam(':birthday', $birthday, PDO::PARAM_STR);
			$signin -> bindParam(':address', $address, PDO::PARAM_STR);
			$signin -> bindParam(':extnumber', $extnumber, PDO::PARAM_STR);
			$signin -> bindParam(':intnumber', $intnumber, PDO::PARAM_STR);
			$signin -> bindParam(':phonenumber', $phonenumber, PDO::PARAM_STR);
			$signin -> bindParam(':zipcode', $zipcode, PDO::PARAM_STR);
			$signin -> bindParam(':email', $email, PDO::PARAM_STR);
			$signin -> bindParam(':curp', $curp, PDO::PARAM_STR);
			$signin -> execute();
		}*/
        public function setReg($curp, $nombre, $pat, $mat, $estado, $fechanac){
            $full = 1;
            $signin = $this -> Connection -> prepare($this -> SQL[1]);
            $signin -> bindParam(':curp', $curp, PDO::PARAM_STR);
            $signin -> bindParam(':nombre', $nombre, PDO::PARAM_STR);
            $signin -> bindParam(':pat', $pat, PDO::PARAM_STR);
            $signin -> bindParam(':mat', $mat, PDO::PARAM_STR);
            $signin -> bindParam(':fechanac', $fechanac, PDO::PARAM_STR);
            $signin -> bindParam(':full', $full, PDO::PARAM_STR);


            $signin -> execute();
        }
	}
?>