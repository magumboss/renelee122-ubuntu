<?php

session_start();
if (!isset($_SESSION['CURP']))
{
    echo "<meta http-equiv='refresh' content='0;url=/'>";
}

      /*session_start();
                     if(!isset($_SESSION["nom"])){
                        echo '<script language = javascript>
                        self.location = "../login.php"
                            </script>';
                    }*/
//if(isset($_POST["solicitud"])){

    // get the HTML
    ob_start();
    include('ficha.php');
    $content = ob_get_clean();

    // convert in PDF
    require_once('html2pdf/html2pdf.class.php');
    try
    {
        $html2pdf = new HTML2PDF('P', 'A5', 'fr');
//      $html2pdf->setModeDebug();

        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));
        $html2pdf->Output('ficha.pdf');
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }
//}


