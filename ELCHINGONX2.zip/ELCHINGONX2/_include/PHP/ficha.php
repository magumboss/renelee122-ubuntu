<?php
session_start();
if (!isset($_SESSION['CURP']))
{
    echo "<meta http-equiv='refresh' content='0;url=/'>";
}
?>


<!-- saved from url=(0087)http://www.pdf.investintech.com/preview/93c90e56-0ea6-11e7-922a-002590d31986/index.html -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
<!--
span.cls_002{font-family:Arial,serif;font-size:12.1px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
div.cls_002{font-family:Arial,serif;font-size:12.1px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
-->
</style>
</head>
<body>
<div style="position:absolute;left:50%;margin-left:-306px;top:0px;width:612px;height:792px;border-style:outset;overflow:hidden">
<div style="position:absolute;left:0px;top:0px">
<img src="ficha_files/background1.jpg" width="612" height="792"></div>
<div style="position:absolute;left:124.76px;top:115.92px" class="cls_002"><span class="cls_002"><?php echo $_SESSION['info']['nomcarrera']; ?></span></div>
<div style="position:absolute;left:480.76px;top:115.92px" class="cls_002"><span class="cls_002"><?php echo $_SESSION['fechavig']; ?></span></div>
<div style="position:absolute;left:159.29px;top:149.04px" class="cls_002"><span class="cls_002"><?php echo $_SESSION['info']['referencia']; ?></span></div>
<div style="text-transform: uppercase;position:absolute;left:140.30px;top:180.48px" class="cls_002"><span class="cls_002"><?php echo $_SESSION['info']['nombre'] .' '. $_SESSION['info']['paterno'].' '.$_SESSION['info']['materno']; ?></span></div>
<div style="position:absolute;left:72.48px;top:245.04px" class="cls_002"><span class="cls_002">clave 1</span></div>
<div style="position:absolute;left:203.91px;top:245.04px" class="cls_002"><span class="cls_002">PAGO DE EXAMEN</span></div>
<div style="position:absolute;left:458.86px;top:245.04px" class="cls_002"><span class="cls_002">importe1</span></div>
<div style="position:absolute;left:459.61px;top:278.16px" class="cls_002"><span class="cls_002">total1</span></div>
<div style="position:absolute;left:118.60px;top:512.88px" class="cls_002"><span class="cls_002"><?php echo $_SESSION['info']['nomcarrera']; ?></span></div>
<div style="position:absolute;left:482.04px;top:512.88px" class="cls_002"><span class="cls_002"><?php echo $_SESSION['fechavig']; ?></span></div>
<div style="position:absolute;left:162.01px;top:542.16px" class="cls_002"><span class="cls_002"><?php echo $_SESSION['info']['referencia']; ?></span></div>
<div style="text-transform: uppercase;position:absolute;left:140.30px;top:575.28px" class="cls_002"><span class="cls_002"><?php echo $_SESSION['info']['nombre'] .' '. $_SESSION['info']['paterno'].' '.$_SESSION['info']['materno']; ?></span></div>
<div style="position:absolute;left:72.48px;top:637.44px" class="cls_002"><span class="cls_002">Clave 2</span></div>
<div style="position:absolute;left:204.04px;top:637.44px" class="cls_002"><span class="cls_002">PAGO DE EXAMEN</span></div>
<div style="position:absolute;left:459.61px;top:637.44px" class="cls_002"><span class="cls_002">importe2</span></div>
<div style="position:absolute;left:456.90px;top:670.08px" class="cls_002"><span class="cls_002">Total 2</span></div>
</div>



</body></html>